/** Automatically generated file. DO NOT MODIFY */
package com.technotalkative.multiphotoselect;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}